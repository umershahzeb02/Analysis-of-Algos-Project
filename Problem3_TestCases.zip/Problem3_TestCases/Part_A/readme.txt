1. First block of lines has the Nodes & Distances
2. Next there are Possible Paths
3. Very last line has the Average time to move between locations

Note : path costs will be calculated by your algorithum, using the Nodes, their distances and the possible paths 